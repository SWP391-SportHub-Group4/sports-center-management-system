using System.Diagnostics;
using System.Text.Json;
using SportHub.AI.Application.DTOs.Manager;
using SportHub.AI.Application.Interfaces;
using SportHub.AI.Domain.Constants;
using SportHub.AI.Domain.Entities;
using SportHub.BuildingBlocks.Abstractions.Persistence;
using SportHub.BuildingBlocks.SharedKernel.Time;

namespace SportHub.AI.Application.Services;

public sealed class ManagerScheduleSuggestionService(
    ISportHubDbContext db,
    IManagerScheduleContextBuilder contextBuilder,
    IPythonAiClient pythonAiClient,
    IClock clock)
    : IManagerScheduleSuggestionService
{
    public async Task<
        ManagerScheduleSuggestionResponse>
        SuggestAsync(
            Guid managerId,
            ManagerScheduleSuggestionRequest request,
            CancellationToken cancellationToken = default)
    {
        var contextJson =
            await contextBuilder.BuildAsync(
                managerId,
                request,
                cancellationToken);

        var context =
            JsonSerializer.Deserialize<object>(
                contextJson)
            ?? new { };

        var pythonRequest =
            new ManagerSchedulePythonRequest
            {
                SportId =
                    request.SportId,

                CoachId =
                    request.CoachId,

                DefaultRoomId =
                    request.DefaultRoomId,

                StartDate =
                    request.StartDate,

                NumSessions =
                    request.NumSessions,

                ScheduleRules =
                    request.ScheduleRules,

                Context =
                    context
            };

        var stopwatch =
            Stopwatch.StartNew();

        Console.WriteLine(
            "[ManagerAI] Calling Python...");

        var result =
            await pythonAiClient
                .SuggestManagerScheduleAsync(
                    pythonRequest,
                    cancellationToken);

        Console.WriteLine(
            "[ManagerAI] Python returned successfully");

        Console.WriteLine(
            JsonSerializer.Serialize(result));

        stopwatch.Stop();

        var logId =
            Guid.NewGuid();

        var generatedAt =
            clock.UtcNow;

        var elapsedMs =
            (int)Math.Min(
                int.MaxValue,
                stopwatch.ElapsedMilliseconds);
                
        Console.WriteLine(
            "[ManagerAI] Preparing AiLog");

        db.Set<AiLog>().Add(
            new AiLog
            {
                LogId =
                    logId,

                UserId =
                    managerId,

                QueryType =
                    AiQueryTypes
                        .ManagerScheduleSuggestion,

                InputPayload =
                    JsonSerializer.Serialize(
                        pythonRequest),

                ResponsePayload =
                    JsonSerializer.Serialize(
                        result),

                ResponseTimeMs =
                    elapsedMs,

                CreatedAt =
                    generatedAt
            });

        await db.SaveChangesAsync(
            cancellationToken);

        Console.WriteLine(
            "[ManagerAI] AiLog saved");
            
        return new
            ManagerScheduleSuggestionResponse(
                result.StartDate,
                result.NumSessions,
                result.ScheduleRules,
                result.Rationale,
                logId,
                "Python AI Service",
                "Gemini",
                elapsedMs,
                generatedAt);
    }
}