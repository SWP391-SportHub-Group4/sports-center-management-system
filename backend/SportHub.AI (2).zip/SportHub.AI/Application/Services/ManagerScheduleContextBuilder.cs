using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SportHub.AI.Application.DTOs.Manager;
using SportHub.AI.Application.Interfaces;
using SportHub.BuildingBlocks.Abstractions.Persistence;
using SportHub.BuildingBlocks.Abstractions.Scheduling;
using SportHub.Identity.Domain.Entities;
using SportHub.Identity.Domain.Enums;
using SportHub.Scheduling.Catalog.Domain;
using SportHub.Scheduling.Domain.Entities;

namespace SportHub.AI.Application.Services;

public sealed class ManagerScheduleContextBuilder(
    ISportHubDbContext db)
    : IManagerScheduleContextBuilder
{
    public async Task<string> BuildAsync(
        Guid managerId,
        ManagerScheduleSuggestionRequest request,
        CancellationToken cancellationToken = default)
    {
        var sport = await db.Set<Sport>()
            .AsNoTracking()
            .Where(x => x.SportId == request.SportId)
            .Select(x => new
            {
                x.SportId,
                x.Code,
                x.Name,
                x.Description,
                x.IsActive,
                GroupCourse = x.Services
                    .Where(s =>
                        s.ServiceType == SportServiceType.GroupCourse &&
                        s.IsEnabled)
                    .Select(s => new
                    {
                        s.DefaultSessionMinutes,
                        s.DefaultMaxCapacity
                    })
                    .FirstOrDefault()
            })
            .FirstOrDefaultAsync(cancellationToken);

        var room = await db.Set<Room>()
            .AsNoTracking()
            .Where(x => x.RoomId == request.DefaultRoomId)
            .Select(x => new
            {
                x.RoomId,
                x.Name,
                x.Capacity,
                x.RoomTypeId,
                x.IsActive
            })
            .FirstOrDefaultAsync(cancellationToken);

        object? coach = null;

        if (request.CoachId.HasValue)
        {
            var coachId = request.CoachId.Value;

            coach = await db.Set<UserAccount>()
                .AsNoTracking()
                .Where(x => x.UserId == coachId)
                .Select(x => new
                {
                    x.UserId,
                    x.Email,
                    FullName = x.Profile != null
                        ? x.Profile.FullName
                        : x.Email,
                    Active =
                        x.Status == UserStatus.Active,
                    SportIds = db.Set<UserSportSpecialty>()
                        .Where(s => s.UserId == coachId)
                        .Select(s => s.SportId)
                        .ToList()
                })
                .FirstOrDefaultAsync(cancellationToken);
        }

        var context = new
        {
            application = "SportHub",

            actor = new
            {
                role = "CenterManager",
                userId = managerId
            },

            currentOperation = new
            {
                operation = "CREATE_OR_UPDATE",
                page = "MANAGER_CLASS_EDITOR",
                step = "SCHEDULE",
                entityType = "CLASS"
            },

            permissions = new
            {
                editableFields = new[]
                {
                    "startDate",
                    "numSessions",
                    "scheduleRules"
                },

                lockedFields = new[]
                {
                    "sportId",
                    "coachId",
                    "defaultRoomId",
                    "capacity",
                    "price",
                    "costAmount"
                }
            },

            selectedEntities = new
            {
                sport,
                coach,
                room
            },

            currentDraft = new
            {
                request.StartDate,
                request.NumSessions,
                request.ScheduleRules
            },

            schedulePolicy = new
            {
                availabilityVerifiedByAi = false,
                backendValidationRequired = true,
                aiMayPublish = false,
                aiMaySave = false,
                aiMayChangeCoach = false,
                aiMayChangeRoom = false,
                aiMayChangeSport = false
            }
        };

        return JsonSerializer.Serialize(
            context,
            new JsonSerializerOptions
            {
                PropertyNamingPolicy =
                    JsonNamingPolicy.CamelCase
            });
    }
}