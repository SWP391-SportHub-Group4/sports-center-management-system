"use client";

import { CoachAiAssistant } from "@/features/coach/coach-ai-assistant";

import Link from "next/link";
import { BookOpen, CalendarDays, History } from "lucide-react";
import { usePathname, useRouter } from "next/navigation";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { HOME_BY_ROLE, useAuth, type Role } from "@/lib/auth";
import { useLanguage } from "@/lib/language";
import type { Translations } from "@/locales/en";
import { NotificationBell } from "./NotificationBell";
import { useManagerRequestUnread } from "@/lib/manager-request-reads";
import {
  IconKeyboard,
  IconLogout,
  IconMenu,
  IconClose,
  IconSettings,
  IconUser,
} from "@/components/icons";
import shell from "./MemberShell.module.css";
import styles from "./AppShell.module.css";
import { AvatarImage } from "./AvatarImage";

type NavLabelKey = keyof Translations["navigation"]["items"];

export interface NavItem {
  href: string;
  labelKey: NavLabelKey;
}

/**
 * Phím tắt và route cố định theo mã; nội dung hiển thị (tiêu đề/mô tả song ngữ) lấy từ
 * t.navigation.receptionistShortcuts để không lặp chuỗi cứng ở đây.
 */
export const RECEPTIONIST_SHORTCUTS: Record<
  string,
  {
    key: string;
    label: string;
    contentKey: keyof Translations["navigation"]["receptionistShortcuts"];
  }
> = {
  "/receptionist": {
    key: "0",
    label: "Alt + 0",
    contentKey: "overview",
  },
  "/receptionist/gym-checkin": {
    key: "1",
    label: "Alt + 1",
    contentKey: "gymCheckin",
  },
  "/receptionist/schedule": {
    key: "2",
    label: "Alt + 2",
    contentKey: "attendance",
  },
  "/receptionist/members": {
    key: "3",
    label: "Alt + 3",
    contentKey: "registrations",
  },
};

/**
 * Điều hướng theo vai trò. Menu ẩn KHÔNG phải là cơ chế phân quyền — mọi endpoint đều có
 * [Authorize(Policy=…)] ở backend; đây chỉ là để người dùng không thấy những màn hình họ
 * không dùng được.
 */
export const NAV_BY_ROLE: Record<Role, NavItem[]> = {
  // Member dùng MemberShell, không dùng AppShell — nhánh này giữ lại chỉ để Record đủ key.
  Member: [
    { href: "/member", labelKey: "overview" },
    { href: "/member/schedule", labelKey: "classSchedule" },
    { href: "/member/my-registrations", labelKey: "myRegistrations" },
    { href: "/member/my-plans", labelKey: "myMembershipPlans" },
    { href: "/member/invoices", labelKey: "invoices" },
    { href: "/member/training?tab=profile", labelKey: "trainingProfile" },
  ],
  Receptionist: [
    { href: "/receptionist", labelKey: "frontDesk" },
    { href: "/receptionist/members", labelKey: "members" },
    { href: "/receptionist/schedule", labelKey: "activitySchedule" },
    { href: "/receptionist/support", labelKey: "support" },
  ],
  Coach: [
    { href: "/coach", labelKey: "overview" },
    { href: "/coach/schedule", labelKey: "teachingSchedule" },
    { href: "/coach/members", labelKey: "assignedMembers" },
    { href: "/coach/attendance", labelKey: "attendance" },
    { href: "/coach/support", labelKey: "requests" },
  ],
  CenterManager: [
    { href: "/manager", labelKey: "overview" },
    { href: "/manager/sports", labelKey: "sports" },
    { href: "/manager/facilities", labelKey: "courts" },
    { href: "/manager/people", labelKey: "people" },
    { href: "/manager/incidents", labelKey: "incident" },
    { href: "/manager/notices", labelKey: "notices" },
    { href: "/manager/media", labelKey: "media" },
    { href: "/manager/requests", labelKey: "requests" },
    { href: "/manager/classes", labelKey: "classes" },
    { href: "/manager/membership-plans", labelKey: "membershipPlans" },
    { href: "/manager/finance", labelKey: "finance" },
    { href: "/manager/points", labelKey: "pointWallets" },
    { href: "/manager/reports", labelKey: "report" },
  ],
  SystemAdministrator: [
    { href: "/admin", labelKey: "overview" },
    { href: "/admin/users", labelKey: "usersRoles" },
    { href: "/admin/audit-log", labelKey: "auditLog" },
    { href: "/admin/support", labelKey: "support" },
  ],
};

export function getNavForUser(user: {
  role: Role;
  sportIds: number[];
  approvalStatus?: string | null;
}): NavItem[] {
  if (user.role !== "Coach") return NAV_BY_ROLE[user.role];
  return [
    { href: "/coach/schedule", labelKey: "teachingSchedule" },
    { href: "/coach/classes", labelKey: "assignedClasses" },
    { href: "/coach/members", labelKey: "classStudents" },
    { href: "/coach/support", labelKey: "requests" },
  ];
}

type GroupKey = keyof Translations["navigation"]["groups"];
type NavEntry =
  | { kind: "link"; href: string; label: string }
  | {
      kind: "group";
      key: GroupKey;
      label: string;
      items: { href: string; label: string }[];
    };

/** Nhóm menu theo vai trò; mục không nằm trong cấu hình vẫn hiện (dạng link) để không mất lối vào. */
const GROUP_SPEC: Partial<Record<Role, (string | [GroupKey, string[]])[]>> = {
  CenterManager: [
    "/manager",
    [
      "catalog",
      [
        "/manager/sports",
        "/manager/facilities",
        "/manager/membership-plans",
        "/manager/classes",
      ],
    ],
    "/manager/media",
    "/manager/people",
    ["finance", ["/manager/finance", "/manager/points", "/manager/reports"]],
    [
      "supportCommunications",
      ["/manager/requests", "/manager/incidents", "/manager/notices"],
    ],
  ],
  Coach: [
    "/coach",
    "/coach/schedule",
    "/coach/classes",
    "/coach/members",
    "/coach/attendance",
  ],
};

function buildNav(items: NavItem[], role: Role, t: Translations): NavEntry[] {
  const label = (item: NavItem) => t.navigation.items[item.labelKey];
  const byHref = new Map(items.map((i) => [i.href, i]));
  const used = new Set<string>();
  const entries: NavEntry[] = [];
  for (const spec of GROUP_SPEC[role] ?? items.map((i) => i.href)) {
    if (typeof spec === "string") {
      const item = byHref.get(spec);
      if (!item) continue;
      used.add(spec);
      entries.push({ kind: "link", href: item.href, label: label(item) });
      continue;
    }
    const [key, hrefs] = spec;
    const present = hrefs.flatMap((h) => {
      const item = byHref.get(h);
      return item ? [{ href: item.href, label: label(item) }] : [];
    });
    hrefs.forEach((h) => used.add(h));
    if (present.length)
      entries.push({
        kind: "group",
        key,
        label: t.navigation.groups[key],
        items: present,
      });
  }
  for (const item of items)
    if (!used.has(item.href))
      entries.push({ kind: "link", href: item.href, label: label(item) });
  return entries;
}

/** Trang gốc của nhánh chỉ sáng ở đúng nó; các mục còn lại khớp theo tiền tố. */
function isActiveHref(pathname: string, href: string, root: string) {
  return (
    pathname === href ||
    (href !== root && pathname.startsWith(`${href}/`)) ||
    (href === "/manager/people" &&
      /^\/manager\/(members|coaches)(\/|$)/.test(pathname))
  );
}

const FrameContext = createContext(false);

function RequestUnreadBadge({ count }: { count: number }) {
  if (count <= 0) return null;
  return (
    <span
      className={styles.requestBadge}
      aria-label={`${count} unread requests`}
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}

function NavGroup({
  entry,
  pathname,
  root,
  unreadRequests = 0,
}: {
  entry: Extract<NavEntry, { kind: "group" }>;
  pathname: string;
  root: string;
  unreadRequests?: number;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const active = entry.items.some((i) => isActiveHref(pathname, i.href, root));

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        ref.current?.querySelector("button")?.focus();
      }
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div className={styles.group} ref={ref}>
      <button
        type="button"
        className={`${shell.navLink} ${styles.groupButton} ${active ? shell.navLinkActive : ""}`}
        aria-expanded={open}
        aria-controls={`group-${entry.key}`}
        data-active={active || undefined}
        onClick={() => setOpen((o) => !o)}
      >
        {entry.label}
        {entry.items.some((item) => item.href === "/manager/requests") && (
          <RequestUnreadBadge count={unreadRequests} />
        )}
        <svg
          width="10"
          height="10"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
      {open && (
        <ul className={styles.groupMenu} id={`group-${entry.key}`}>
          {entry.items.map((item) => {
            const on = isActiveHref(pathname, item.href, root);
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={on ? "page" : undefined}
                  className={`${styles.groupLink} ${on ? styles.groupLinkActive : ""}`}
                >
                  {item.label}
                  {item.href === "/manager/requests" && (
                    <RequestUnreadBadge count={unreadRequests} />
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

/**
 * Khung điều hướng của nhân sự: thanh trên cùng cố định (sticky) thay cho sidebar. Đặt một lần ở layout
 * từng nhánh (/manager, /coach, ...) để chuyển trang không dựng lại thanh điều hướng.
 */
export function AppFrame({
  allow,
  children,
}: {
  allow: Role[];
  children: ReactNode;
}) {
  const { user, loading, logout } = useAuth();
  const { language, t } = useLanguage();
  const router = useRouter();
  const pathname = usePathname();
  const unreadRequests = useManagerRequestUnread();
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [userMenu, setUserMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const userRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace(
        `/login?next=${encodeURIComponent(window.location.pathname + window.location.search)}`,
      );
      return;
    }
    // Vào nhầm nhánh của vai trò khác thì đưa về trang chủ của chính mình, không hiện 403
    // trống trơn — người dùng thường tới đây do bookmark cũ chứ không phải cố tình.
    if (!allow.includes(user.role)) router.replace(HOME_BY_ROLE[user.role]);
  }, [user, loading, allow, router, pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 4);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!userMenu) return;
    const onDown = (e: MouseEvent) => {
      if (userRef.current && !userRef.current.contains(e.target as Node))
        setUserMenu(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [userMenu]);

  // Global Receptionist Keyboard Navigation Shortcuts (Alt + 0..5, Alt + /)
  useEffect(() => {
    if (user?.role !== "Receptionist") return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const targetTag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      const isInput =
        targetTag === "input" ||
        targetTag === "textarea" ||
        (e.target as HTMLElement)?.isContentEditable;

      if (e.altKey && e.key === "/") {
        e.preventDefault();
        setShowShortcuts((prev) => !prev);
        return;
      }

      if (e.key === "?" && !isInput && !e.altKey && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setShowShortcuts((prev) => !prev);
        return;
      }

      if (e.key === "Escape" && showShortcuts) {
        e.preventDefault();
        setShowShortcuts(false);
        return;
      }

      if (e.altKey && !e.ctrlKey && !e.metaKey) {
        const key = e.key.toLowerCase();
        const route =
          key === "d" || key === "h"
            ? "/receptionist"
            : Object.entries(RECEPTIONIST_SHORTCUTS).find(
                ([, sc]) => sc.key === key,
              )?.[0];
        if (route) {
          e.preventDefault();
          setShowShortcuts(false);
          router.push(route);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [user?.role, router, showShortcuts]);

  if (loading || !user || !allow.includes(user.role)) {
    return (
      <div className="auth">
        <div className="auth__card">
          <p className="muted">{t.navigation.loadingSession}</p>
        </div>
      </div>
    );
  }

  const items = getNavForUser(user);
  const root = items[0].href;
  const entries = buildNav(items, user.role, t);
  const roleDisplay = t.navigation.roleLabel[user.role];
  const usesStaffPalette =
    user.role === "CenterManager" || user.role === "Coach";
  const roleShell =
    user.role === "CenterManager"
      ? styles.managerShell
      : user.role === "Coach"
        ? styles.coachShell
        : "";
  return (
    <div
      className={`${shell.shell} ${usesStaffPalette ? styles.staffPalette : ""} ${roleShell}`}
    >
      {user.role === "Coach" && <CoachAiAssistant />}
      <a href="#main-content" className="skip-link">
        {language === "en"
          ? "Skip to main content"
          : "Chuyển tới nội dung chính"}
      </a>
      <header className={shell.header} data-scrolled={scrolled || undefined}>
        <div
          className={`${shell.headerInner} ${user.role === "SystemAdministrator" ? styles.adminHeader : ""} ${user.role === "CenterManager" ? styles.managerHeader : ""}`}
        >
          <Link href={root} className={shell.brandGroup}>
            <span className={shell.brandLogo}>
              Sport<span className={shell.brandLogoAccent}>Hub</span>
            </span>
          </Link>

          <nav
            className={`${styles.staffNav} ${user.role === "SystemAdministrator" ? styles.adminNav : ""}`}
            aria-label={roleDisplay}
          >
            {entries.map((entry) =>
              entry.kind === "link" ? (
                <Link
                  key={entry.href}
                  href={entry.href}
                  aria-current={
                    isActiveHref(pathname, entry.href, root)
                      ? "page"
                      : undefined
                  }
                  className={`${shell.navLink} ${isActiveHref(pathname, entry.href, root) ? shell.navLinkActive : ""}`}
                >
                  {entry.label}
                </Link>
              ) : (
                <NavGroup
                  key={`${entry.key}:${pathname}`}
                  entry={entry}
                  pathname={pathname}
                  root={root}
                  unreadRequests={unreadRequests}
                />
              ),
            )}
          </nav>

          <div className={shell.headerActions}>
            {user.role === "Receptionist" && (
              <button
                type="button"
                className={styles.shortcutsButton}
                onClick={() => setShowShortcuts((prev) => !prev)}
                title={t.navigation.shortcutsButtonTitle}
              >
                <IconKeyboard size={16} aria-hidden="true" />
                <span>{t.navigation.shortcutsButton}</span>
              </button>
            )}
            <NotificationBell />
            <div
              className={`${shell.userMenuWrapper} ${user.role === "Coach" ? styles.coachAccount : ""}`}
              ref={userRef}
              onKeyDown={(event) => {
                if (event.key === "Escape") {
                  setUserMenu(false);
                  userRef.current
                    ?.querySelector<HTMLButtonElement>("button")
                    ?.focus();
                }
              }}
            >
              <button
                type="button"
                className={shell.userButton}
                onClick={() => setUserMenu((p) => !p)}
                aria-expanded={userMenu}
                data-testid="user-profile-button"
                aria-label={user.fullName || user.email}
              >
                <AvatarImage
                  userId={user.userId}
                  name={user.fullName || user.email}
                  avatarUrl={user.avatarUrl}
                  size={36}
                  className={`${shell.userAvatar} ${usesStaffPalette ? styles.managerAvatar : ""}`}
                />
                <span className={shell.userName}>
                  {user.fullName || user.email}
                </span>
                <span className={shell.dropdownArrow} aria-hidden="true">
                  <svg
                    width="10"
                    height="10"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </span>
              </button>
              {userMenu && (
                <div className={shell.userDropdown}>
                  <div className={shell.dropdownHeader}>
                    <div className={shell.dropdownName}>
                      {user.fullName || user.email}
                    </div>
                  </div>
                  <Link
                    href="/account"
                    className={`${shell.dropdownItem} ${styles.profileItem}`}
                    aria-current={pathname === "/account" ? "page" : undefined}
                    onClick={() => setUserMenu(false)}
                  >
                    <IconUser size={15} />
                    <span>{t.navigation.myAccount}</span>
                  </Link>
                  {user.role === "CenterManager" && (
                    <>
                      <Link
                        href="/manager/schedule"
                        className={`${shell.dropdownItem} ${styles.profileItem}`}
                        aria-current={
                          isActiveHref(pathname, "/manager/schedule", root)
                            ? "page"
                            : undefined
                        }
                        onClick={() => setUserMenu(false)}
                      >
                        <CalendarDays size={15} aria-hidden="true" />
                        <span>{t.navigation.items.activitySchedule}</span>
                      </Link>
                      <Link
                        href="/manager/audit-log"
                        className={`${shell.dropdownItem} ${styles.profileItem}`}
                        aria-current={
                          isActiveHref(pathname, "/manager/audit-log", root)
                            ? "page"
                            : undefined
                        }
                        onClick={() => setUserMenu(false)}
                      >
                        <History size={15} aria-hidden="true" />
                        <span>{t.navigation.items.auditLog}</span>
                      </Link>
                    </>
                  )}
                  {user.role === "CenterManager" && (
                    <Link
                      href="/manager/settings"
                      className={`${shell.dropdownItem} ${styles.profileItem}`}
                      aria-current={
                        isActiveHref(pathname, "/manager/settings", root)
                          ? "page"
                          : undefined
                      }
                      onClick={() => setUserMenu(false)}
                    >
                      <IconSettings size={15} />
                      <span>{t.navigation.items.systemSettings}</span>
                    </Link>
                  )}
                  {user.role === "CenterManager" && (
                    <Link
                      href="/manager/ai-knowledge"
                      className={`${shell.dropdownItem} ${styles.profileItem}`}
                      aria-current={
                        pathname.startsWith("/manager/ai-knowledge")
                          ? "page"
                          : undefined
                      }
                      onClick={() => setUserMenu(false)}
                    >
                      <BookOpen size={15} aria-hidden="true" />
                      <span>AI Knowledge</span>
                    </Link>
                  )}
                  <div className={shell.dropdownDivider} />
                  <button
                    type="button"
                    className={`${shell.dropdownItem} ${shell.logoutItem} ${styles.profileItem}`}
                    onClick={() => {
                      setUserMenu(false);
                      logout();
                    }}
                  >
                    <IconLogout size={15} />
                    <span>{t.navigation.logOut}</span>
                  </button>
                </div>
              )}
            </div>
            <button
              type="button"
              className={styles.menuButton}
              onClick={() => setDrawer(true)}
              aria-label={t.nav.openNav}
            >
              <IconMenu size={20} />
            </button>
          </div>
        </div>
      </header>

      {drawer && (
        <div
          className={shell.mobileDrawerOverlay}
          onClick={() => setDrawer(false)}
        >
          <div
            className={shell.mobileDrawer}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={shell.mobileDrawerHeader}>
              <span className={shell.brandLogo}>
                Sport<span className={shell.brandLogoAccent}>Hub</span>
              </span>
              <button
                type="button"
                className={shell.mobileDrawerClose}
                onClick={() => setDrawer(false)}
                aria-label={t.nav.closeNav}
              >
                <IconClose size={20} />
              </button>
            </div>
            <div className={shell.mobileNavLinks}>
              {entries.map((entry) =>
                entry.kind === "link" ? (
                  <Link
                    key={entry.href}
                    href={entry.href}
                    aria-current={
                      isActiveHref(pathname, entry.href, root)
                        ? "page"
                        : undefined
                    }
                    className={`${shell.mobileNavLink} ${isActiveHref(pathname, entry.href, root) ? shell.mobileNavLinkActive : ""}`}
                    onClick={() => setDrawer(false)}
                  >
                    {entry.label}
                  </Link>
                ) : (
                  <div key={entry.key} className={styles.drawerGroup}>
                    <p className={styles.drawerGroupLabel}>
                      {entry.label}
                      {entry.items.some(
                        (item) => item.href === "/manager/requests",
                      ) && <RequestUnreadBadge count={unreadRequests} />}
                    </p>
                    {entry.items.map((item) => {
                      const on = isActiveHref(pathname, item.href, root);
                      return (
                        <Link
                          key={item.href}
                          href={item.href}
                          aria-current={on ? "page" : undefined}
                          className={`${shell.mobileNavLink} ${on ? shell.mobileNavLinkActive : ""}`}
                          onClick={() => setDrawer(false)}
                        >
                          {item.label}
                          {item.href === "/manager/requests" && (
                            <RequestUnreadBadge count={unreadRequests} />
                          )}
                        </Link>
                      );
                    })}
                  </div>
                ),
              )}
              <Link
                href="/account"
                className={shell.mobileNavLink}
                onClick={() => setDrawer(false)}
              >
                <IconUser size={16} style={{ marginRight: 8 }} />
                <span>{t.navigation.myAccount}</span>
              </Link>
              <button
                type="button"
                className={`${shell.mobileNavLink} ${shell.logoutItem}`}
                onClick={() => {
                  setDrawer(false);
                  logout();
                }}
              >
                <IconLogout size={16} style={{ marginRight: 8 }} />
                <span>{t.navigation.logOut}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <main id="main-content" className={styles.main} tabIndex={-1}>
        <FrameContext.Provider value={true}>{children}</FrameContext.Provider>
      </main>

      {showShortcuts && user.role === "Receptionist" && (
        <div
          className="shortcut-modal__backdrop"
          onClick={() => setShowShortcuts(false)}
          role="dialog"
          aria-modal="true"
          aria-label={t.navigation.shortcutsModalTitle}
        >
          <div className="shortcut-modal" onClick={(e) => e.stopPropagation()}>
            <div className="shortcut-modal__header">
              <h3 className="shortcut-modal__title">
                <IconKeyboard size={18} aria-hidden="true" />
                <span>{t.navigation.shortcutsModalTitle}</span>
              </h3>
              <button
                type="button"
                className="shortcut-modal__close"
                onClick={() => setShowShortcuts(false)}
                aria-label={t.navigation.shortcutsCloseLabel}
              >
                ✕
              </button>
            </div>
            <div className="shortcut-modal__body">
              {Object.entries(RECEPTIONIST_SHORTCUTS).map(([route, sc]) => {
                const content =
                  t.navigation.receptionistShortcuts[sc.contentKey];

                return (
                  <Link
                    key={route}
                    href={route}
                    className="shortcut-row"
                    onClick={() => setShowShortcuts(false)}
                  >
                    <div>
                      <div className="shortcut-row__action">
                        {content.title}
                      </div>
                      <div className="shortcut-row__desc">{content.desc}</div>
                    </div>
                    <kbd className="shortcut-row__kbd">{sc.label}</kbd>
                  </Link>
                );
              })}
            </div>
            <div className="shortcut-modal__footer">
              <span>{t.navigation.shortcutsEscapeHint}</span>
              <kbd className="sidebar__kbd">Alt + /</kbd>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/** Tiêu đề trang; chạy bên trong khung. */
function PageBody({
  title,
  description,
  hidePageHeader = false,
  children,
}: {
  title: string;
  description?: string;
  hidePageHeader?: boolean;
  children: ReactNode;
}) {
  return (
    <>
      {!hidePageHeader && (
        <div className={styles.pageHeader}>
          <h1>{title}</h1>
          {description && <p>{description}</p>}
        </div>
      )}
      <div className="content">{children}</div>
    </>
  );
}

export function AppShell({
  title,
  description,
  hidePageHeader,
  allow,
  children,
}: {
  title: string;
  description?: string;
  hidePageHeader?: boolean;
  /** Vai trò được phép xem nhánh này. Bảo vệ route ở client, không thay cho RBAC ở API. */
  allow: Role[];
  /** Giữ để không phải sửa nơi gọi; thanh điều hướng trên cùng không còn cần chế độ này. */
  operationalLayout?: boolean;
  children: ReactNode;
}) {
  const inFrame = useContext(FrameContext);
  const page = (
    <PageBody
      title={title}
      description={description}
      hidePageHeader={hidePageHeader}
    >
      {children}
    </PageBody>
  );
  return inFrame ? page : <AppFrame allow={allow}>{page}</AppFrame>;
}
