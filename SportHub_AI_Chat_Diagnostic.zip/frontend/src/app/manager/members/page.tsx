import { redirect } from "next/navigation";
export default function Page() {
  redirect("/manager/people?role=Member");
}
