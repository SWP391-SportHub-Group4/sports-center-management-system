using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using SportHub.BuildingBlocks.Abstractions.Audit;
using SportHub.BuildingBlocks.Abstractions.Payment;
using SportHub.BuildingBlocks.Abstractions.Configuration;
using SportHub.BuildingBlocks.Abstractions.Persistence;
using SportHub.BuildingBlocks.Abstractions.Scheduling;
using SportHub.BuildingBlocks.SharedKernel.Errors;
using SportHub.BuildingBlocks.SharedKernel.Time;
using SportHub.Scheduling.Domain.Entities;
using SportHub.Scheduling.Domain.Enums;
using SportHub.Scheduling.Application.Services;
using SportHub.Scheduling.Threshold.Domain;

namespace SportHub.Scheduling.Threshold.Application;

/// <summary>Authenticated owner response to a per-enrollment threshold link; selecting the same choice is idempotent.</summary>
public sealed class ThresholdResponseService(ISportHubDbContext db, IClassEnrollmentFulfillment classes,
    IRefundCreditService refunds, IInvoiceDraftWriter invoiceDrafts, ISystemSettingProvider settings,
    ICheckoutLifecycleService checkoutLifecycle, IAuditWriter audit, IClock clock)
{
    public async Task<ThresholdResponseView> GetAsync(Guid? id, string? token, Guid memberId, CancellationToken ct)
    {
        var query = db.Set<ThresholdResponse>().AsNoTracking().Where(x => x.MemberId == memberId);
        if (id.HasValue) query = query.Where(x => x.ThresholdResponseId == id);
        else
        {
            if (string.IsNullOrWhiteSpace(token) || token.Length > 128) throw new BadRequestException("invalid_threshold_response", "Invalid threshold response.");
            var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
            query = query.Where(x => x.TokenHash == hash);
        }
        var response = await query.SingleOrDefaultAsync(ct) ?? throw new NotFoundException("threshold_response_not_found", "Threshold response not found.");
        var course = await db.Set<Class>().AsNoTracking().SingleAsync(x => x.ClassId == response.ClassId, ct);
        var itemId = await db.Set<Enrollment>().Where(e => e.EnrollmentId == response.EnrollmentId).Select(e => e.InvoiceItemId).SingleAsync(ct);
        var remaining = itemId.HasValue ? await refunds.GetRemainingItemValueVndAsync(itemId.Value, ct) : 0;
        var resolvedByClass = response.ResolutionStatus == ThresholdResolutionStatus.Pending
            && course.ThresholdStatus is ThresholdStatus.Met or ThresholdStatus.WaivedByManager;
        return new(response.ThresholdResponseId, course.ClassId, course.Name, course.SportId, remaining,
            response.DeadlineUtc, response.Choice?.ToString(), response.TargetClassId,
            resolvedByClass ? ThresholdResolutionStatus.Completed.ToString() : response.ResolutionStatus.ToString(),
            response.AdditionalInvoiceId, clock.UtcNow, course.Status == ClassStatus.Cancelled);
    }

    public async Task<object> QuoteTransferAsync(Guid id, int targetClassId, Guid memberId, CancellationToken ct)
    {
        var source = await GetAsync(id, null, memberId, ct);
        if (source.ClassCancelled || source.Choice is not null || source.DeadlineUtc <= clock.UtcNow)
            throw new ConflictException("threshold_response_closed", "Threshold response closed.");
        if (targetClassId == source.ClassId) throw new BadRequestException("transfer_same_class", "Transfer same class.");
        var target = await GetTargetQuoteAsync(targetClassId, ct);
        if (target.SportId != source.SportId) throw new ConflictException("transfer_sport_mismatch", "Transfer sport mismatch.");
        var difference = target.Price - source.PaidValueVnd;
        if (difference % 1000 != 0) throw new ConflictException("transfer_value_not_point_divisible", "Transfer value not point divisible.");
        return new { targetClassId, targetPrice = target.Price, sourceValue = source.PaidValueVnd,
            cashDifference = Math.Max(0, difference), walletCreditPoints = difference < 0 ? (int)(-difference / 1000) : 0 };
    }

    public async Task<IReadOnlyList<ThresholdResponseView>> MineAsync(Guid memberId, CancellationToken ct)
    {
        var ids = await db.Set<ThresholdResponse>().Where(x => x.MemberId == memberId).OrderByDescending(x => x.CreatedAtUtc).Take(100).Select(x => x.ThresholdResponseId).ToListAsync(ct);
        var result = new List<ThresholdResponseView>();
        foreach (var id in ids) result.Add(await GetAsync(id, null, memberId, ct));
        return result;
    }

    public async Task<ThresholdResponseResult> RespondByIdAsync(Guid id, ThresholdResponseChoice choice, int? targetClassId, Guid memberId, CancellationToken ct)
    {
        var hash = await db.Set<ThresholdResponse>().Where(x => x.ThresholdResponseId == id && x.MemberId == memberId).Select(x => x.TokenHash).SingleOrDefaultAsync(ct)
            ?? throw new NotFoundException("threshold_response_not_found", "Threshold response not found.");
        return await RespondHashedAsync(hash, choice, targetClassId, memberId, ct);
    }

    public async Task<ThresholdResponseResult> RespondAsync(string token, ThresholdResponseChoice choice,
        int? targetClassId, Guid memberId, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(token) || token.Length > 128 || !Enum.IsDefined(choice))
            throw new BadRequestException("invalid_threshold_response", "Invalid threshold response.");
        if (choice == ThresholdResponseChoice.Transfer && targetClassId is null)
            throw new BadRequestException("target_class_required", "Target class required.");
        if (choice != ThresholdResponseChoice.Transfer && targetClassId is not null)
            throw new BadRequestException("target_class_unexpected", "Target class unexpected.");
        var tokenHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
        return await RespondHashedAsync(tokenHash, choice, targetClassId, memberId, ct);
    }

    private async Task<ThresholdResponseResult> RespondHashedAsync(string tokenHash, ThresholdResponseChoice choice, int? targetClassId, Guid memberId, CancellationToken ct)
    {
        if (!Enum.IsDefined(choice)) throw new BadRequestException("invalid_threshold_response", "Invalid threshold response.");
        if (choice == ThresholdResponseChoice.Transfer && targetClassId is null) throw new BadRequestException("target_class_required", "Target class required.");
        if (choice != ThresholdResponseChoice.Transfer && targetClassId is not null) throw new BadRequestException("target_class_unexpected", "Target class unexpected.");
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var rows = await db.Set<ThresholdResponse>().FromSqlInterpolated($"""
            SELECT * FROM class_threshold_responses WHERE token_hash = {tokenHash} FOR UPDATE
            """).ToListAsync(ct);
        var response = rows.SingleOrDefault() ?? throw new NotFoundException("threshold_response_not_found", "Threshold response not found.");
        if (response.MemberId != memberId)
            throw new ForbiddenException("threshold_response_not_owned", "Threshold response not owned.");
        if (response.Choice is not null)
        {
            if (response.Choice != choice || response.TargetClassId != targetClassId)
                throw new ConflictException("threshold_response_already_submitted", "Threshold response already submitted.");
            if (response.ResolutionStatus == ThresholdResolutionStatus.AwaitingPayment
                && response.AdditionalInvoiceId is Guid priorInvoiceId)
            {
                var priorState = await checkoutLifecycle.GetStateAsync(priorInvoiceId, ct);
                if (priorState.InvoiceStatus == "Issued" && priorState.ExpiresAtUtc > clock.UtcNow)
                {
                    await tx.CommitAsync(ct);
                    return ToResult(response);
                }
                if (response.DeadlineUtc <= clock.UtcNow)
                    throw new ConflictException("threshold_response_expired", "Threshold response expired.");
                if (priorState.InvoiceStatus == "Issued")
                    await checkoutLifecycle.ReleaseForSystemAsync(priorInvoiceId, "Expired", ct);
                if (priorState.InvoiceStatus is not ("Void" or "Issued"))
                    throw new ConflictException("transfer_payment_reconciliation_pending",
                        "Transfer payment reconciliation pending.");
                var source = await db.Set<Enrollment>().SingleOrDefaultAsync(x => x.EnrollmentId == response.EnrollmentId
                    && x.MemberId == memberId && x.Status == EnrollmentStatus.Confirmed, ct)
                    ?? throw new ConflictException("threshold_enrollment_inactive", "Threshold enrollment inactive.");
                var rootItemId = source.InvoiceItemId
                    ?? throw new ConflictException("threshold_invoice_item_missing", "Threshold invoice item missing.");
                await refunds.LockPaidItemAsync(rootItemId, ct);
                var invoiceId = await CreateTransferCheckoutAsync(response, source, rootItemId,
                    response.TargetClassId!.Value, memberId, ct);
                response.AdditionalInvoiceId = invoiceId;
                response.ResolutionStatus = ThresholdResolutionStatus.AwaitingPayment;
                await db.SaveChangesAsync(ct);
                await tx.CommitAsync(ct);
                return ToResult(response);
            }
            await tx.CommitAsync(ct);
            return ToResult(response);
        }
        if (response.ResolutionStatus != ThresholdResolutionStatus.Pending || response.DeadlineUtc <= clock.UtcNow)
            throw new ConflictException("threshold_response_expired", "Threshold response expired.");

        var course = await db.Set<Class>().AsNoTracking().SingleAsync(x => x.ClassId == response.ClassId, ct);
        if (course.Status is not (ClassStatus.Published or ClassStatus.Cancelled) || course.ThresholdStatus != ThresholdStatus.AtRisk)
            throw new ConflictException("threshold_response_closed", "The class threshold decision is closed.");
        if (course.Status == ClassStatus.Cancelled && choice != ThresholdResponseChoice.Refund)
            throw new ConflictException("cancelled_class_choice_invalid", "This class was cancelled. Choose a points refund.");

        var enrollment = await db.Set<Enrollment>().SingleOrDefaultAsync(x => x.EnrollmentId == response.EnrollmentId
            && x.MemberId == memberId && x.Status == EnrollmentStatus.Confirmed, ct)
            ?? throw new ConflictException("threshold_enrollment_inactive", "Threshold enrollment inactive.");
        var itemId = enrollment.InvoiceItemId
            ?? throw new ConflictException("threshold_invoice_item_missing", "Threshold invoice item missing.");

        Guid? additionalInvoiceId = null;
        if (choice == ThresholdResponseChoice.Refund)
        {
            await refunds.LockPaidItemAsync(itemId, ct);
            await refunds.CreditAsync(new RefundCreditRequest(itemId, 100,
                "Points refunded by member choice after the course missed its break-even threshold", response.ThresholdResponseId), ct);
            await classes.CancelAsync(itemId, EnrollmentEndReason.Refunded, ct);
        }
        else if (choice == ThresholdResponseChoice.Transfer)
        {
            additionalInvoiceId = await TransferAsync(response, enrollment, itemId, targetClassId!.Value, memberId, ct);
        }

        response.Choice = choice;
        response.TargetClassId = targetClassId;
        response.AdditionalInvoiceId = additionalInvoiceId;
        response.ResolutionStatus = additionalInvoiceId is null
            ? ThresholdResolutionStatus.Completed : ThresholdResolutionStatus.AwaitingPayment;
        response.RespondedAtUtc = clock.UtcNow;
        if (additionalInvoiceId is null) response.ResolvedAtUtc = clock.UtcNow;
        audit.Write(new AuditEntry(memberId, "RESPOND_CLASS_THRESHOLD", nameof(ThresholdResponse),
            response.ThresholdResponseId.ToString(), NewValue: System.Text.Json.JsonSerializer.Serialize(new
            {
                choice = choice.ToString(), targetClassId, response.ResolutionStatus
            })));
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return ToResult(response);
    }

    private async Task<Guid?> TransferAsync(ThresholdResponse response, Enrollment source, Guid itemId,
        int targetClassId, Guid memberId, CancellationToken ct)
    {
        if (targetClassId == response.ClassId)
            throw new BadRequestException("transfer_same_class", "Transfer same class.");
        var sourceClass = await db.Set<Class>().AsNoTracking().SingleAsync(x => x.ClassId == source.ClassId, ct);
        var targetQuote = await GetTargetQuoteAsync(targetClassId, ct);
        if (targetQuote.SportId != sourceClass.SportId)
            throw new ConflictException("transfer_sport_mismatch", "Transfer sport mismatch.");
        // Lock the paid item before class rows, matching manager refund order (invoice → item → wallet → class).
        // If later seat or schedule checks fail, the whole transfer and any difference credit roll back.
        await refunds.LockPaidItemAsync(itemId, ct);
        var sourceValue = await refunds.GetRemainingItemValueVndAsync(itemId, ct);
        if (targetQuote.Price > sourceValue)
            return await CreateTransferCheckoutAsync(response, source, itemId, targetClassId, memberId, ct, targetQuote);
        var difference = sourceValue - targetQuote.Price;
        if (difference > 0)
        {
            if (difference % 1_000 != 0)
                throw new ConflictException("transfer_value_not_point_divisible", "Transfer value not point divisible.");
            await refunds.CreditDifferenceAsync(new RefundCreditDifferenceRequest(itemId,
                checked((int)(difference / 1_000)), "Difference refunded after transfer to a lower-priced course",
                response.ThresholdResponseId), ct);
        }

        await db.Database.ExecuteSqlInterpolatedAsync($"SELECT user_id FROM user_accounts WHERE user_id = {memberId} FOR UPDATE", ct);
        await CourseScheduleLock.AcquireAsync(db, changingSchedule: false, ct);
        foreach (var classId in new[] { response.ClassId, targetClassId }.Order())
            await db.Database.ExecuteSqlInterpolatedAsync($"SELECT class_id FROM classes WHERE class_id = {classId} FOR UPDATE", ct);

        if (await db.Set<Enrollment>().AnyAsync(x => x.EnrollmentId == source.EnrollmentId
            && x.Status != EnrollmentStatus.Confirmed, ct))
            throw new ConflictException("transfer_source_inactive", "Transfer source inactive.");

        // The target hold and source release join this transaction; failure keeps the original enrollment active.
        var hold = await classes.ReserveAsync(targetClassId, memberId, null,
            clock.UtcNow.AddMinutes(2), ct, source.EnrollmentId);
        await classes.CancelAsync(itemId, EnrollmentEndReason.TransferredOut, ct);
        await classes.ConfirmAsync(hold.SeatHoldId, itemId, ct,
            source.EnrollmentId, source.TransferDifferenceInvoiceItemId);
        return null;
    }

    private async Task<Guid> CreateTransferCheckoutAsync(ThresholdResponse response, Enrollment source,
        Guid rootItemId, int targetClassId, Guid memberId, CancellationToken ct, ClassQuote? knownQuote = null)
    {
        var sourceClass = await db.Set<Class>().AsNoTracking().SingleAsync(x => x.ClassId == source.ClassId, ct);
        var targetQuote = knownQuote ?? await GetTargetQuoteAsync(targetClassId, ct);
        if (targetQuote.SportId != sourceClass.SportId)
            throw new ConflictException("transfer_sport_mismatch", "Transfer sport mismatch.");
        var sourceValue = await refunds.GetRemainingItemValueVndAsync(rootItemId, ct);
        var difference = targetQuote.Price - sourceValue;
        if (difference <= 0 || difference % 1_000 != 0)
            throw new ConflictException("transfer_difference_invalid", "Transfer difference invalid.");
        var holdMinutes = await CheckoutHoldPolicy.ReadMinutesAsync(settings, ct);
        var expires = clock.UtcNow.AddMinutes(holdMinutes);
        var responseDeadline = response.DeadlineUtc;
        if (expires > responseDeadline) expires = responseDeadline;
        var beforeStart = targetQuote.FirstSessionUtc.UtcDateTime.AddSeconds(-1);
        if (expires > beforeStart) expires = beforeStart;
        if (expires <= clock.UtcNow)
            throw new ConflictException("transfer_checkout_window_closed", "Transfer checkout window closed.");
        var expiresOffset = new DateTimeOffset(DateTime.SpecifyKind(expires, DateTimeKind.Utc));
        await db.Database.ExecuteSqlInterpolatedAsync(
            $"SELECT user_id FROM user_accounts WHERE user_id = {memberId} FOR UPDATE", ct);
        await CourseScheduleLock.AcquireAsync(db, changingSchedule: false, ct);
        foreach (var classId in new[] { response.ClassId, targetClassId }.Order())
            await db.Database.ExecuteSqlInterpolatedAsync($"SELECT class_id FROM classes WHERE class_id = {classId} FOR UPDATE", ct);
        var hold = await classes.ReserveAsync(targetClassId, memberId, null, expiresOffset, ct, source.EnrollmentId);
        var draft = await invoiceDrafts.CreateAsync(new InvoiceDraft(memberId, memberId,
            [new InvoiceDraftItem("ClassTransferDifference", $"Transfer difference for course {targetQuote.ClassId}",
                difference, targetQuote.SportId, targetQuote.ClassId, SourceEnrollmentId: source.EnrollmentId,
                SourceInvoiceItemId: rootItemId, RelatedEntityId: response.ThresholdResponseId, ResourceHoldId: hold.SeatHoldId,
                SportName: targetQuote.SportName)],
            expiresOffset, $"threshold-transfer-{response.ThresholdResponseId:N}"), ct);
        await classes.AttachHoldToInvoiceAsync(hold.SeatHoldId, draft.InvoiceId, ct);
        return draft.InvoiceId;
    }

    private async Task<ClassQuote> GetTargetQuoteAsync(int classId, CancellationToken ct)
    {
        var row = await db.Set<Class>().AsNoTracking().Where(x => x.ClassId == classId)
            .Select(x => new { x.ClassId, x.SportId, SportName = x.Sport!.Name, x.Price, x.Status })
            .SingleOrDefaultAsync(ct) ?? throw new NotFoundException("class_not_found", "Class not found.");
        if (row.Status != ClassStatus.Published)
            throw new ConflictException("transfer_target_not_published", "Transfer target not published.");
        var first = await db.Set<ClassSession>().Where(x => x.ClassId == classId && x.Status != ClassSessionStatus.Cancelled)
            .MinAsync(x => (DateTime?)x.StartAtUtc, ct);
        if (first is null || first <= clock.UtcNow)
            throw new ConflictException("transfer_target_started", "Transfer target started.");
        return new ClassQuote(row.ClassId, row.SportId, row.SportName, row.Price,
            new DateTimeOffset(DateTime.SpecifyKind(first.Value, DateTimeKind.Utc)));
    }

    private static ThresholdResponseResult ToResult(ThresholdResponse response)
        => new(response.ThresholdResponseId, response.Choice?.ToString(), response.TargetClassId,
            response.ResolutionStatus.ToString(), response.DeadlineUtc, response.AdditionalInvoiceId);
}

public sealed record ThresholdResponseResult(Guid ResponseId, [property: SportHub.BuildingBlocks.Api.WireEnum] string? Choice, int? TargetClassId,
    [property: SportHub.BuildingBlocks.Api.WireEnum] string ResolutionStatus, DateTime DeadlineUtc, Guid? AdditionalInvoiceId);

public sealed record ThresholdResponseView(Guid ResponseId, int ClassId, string ClassName, int SportId, decimal PaidValueVnd,
    DateTime DeadlineUtc, [property: SportHub.BuildingBlocks.Api.WireEnum] string? Choice, int? TargetClassId,
    [property: SportHub.BuildingBlocks.Api.WireEnum] string ResolutionStatus, Guid? AdditionalInvoiceId, DateTime ServerNowUtc,
    bool ClassCancelled = false);
